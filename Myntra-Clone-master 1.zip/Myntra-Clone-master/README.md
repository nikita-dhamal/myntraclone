# Myntra-Clone
I Built Myntra Clone from scratch using html, css and javascript. Features include responsive side nav bar, carousel, pop-up offer card, product card and fully responsive. 

## Desktop View
<br>

![m1](https://github.com/Shubham7906/Myntra-Clone/assets/76210714/c1adabc5-2144-4b64-ba55-76fbf1d4cab8)
![m2](https://github.com/Shubham7906/Myntra-Clone/assets/76210714/12525ef4-8a31-4dc5-8ab1-f47efd126ae6)
![m4](https://github.com/Shubham7906/Myntra-Clone/assets/76210714/f7ad4514-08b7-437f-99f5-c69f155da45c)

## Phone View
<br>

![mp1](https://github.com/Shubham7906/Myntra-Clone/assets/76210714/2481374b-1d7c-4257-a50b-4a8da1c64e10)
<br>
![mp2](https://github.com/Shubham7906/Myntra-Clone/assets/76210714/ec11ad6b-efa9-4235-990e-6c1930403244)
<br>
![mp3](https://github.com/Shubham7906/Myntra-Clone/assets/76210714/bdad2a50-cfdb-4486-aa2d-b9419ad83724)

